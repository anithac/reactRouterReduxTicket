
const types = {
  ADD_TICKETS: "commonAction/ADD_TICKETS",
  UPDATE_TICKETS: "commonAction/UPDATE_TICKETS",
};

export const addTickets = (ticket, callback = () => {}) => async dispatch => {
    dispatch({
        type: types.ADD_TICKETS,
        payload: ticket
      });
    
    callback(true);
  
};

export const updateTickets= (ticketsData, callback = () => {}) => async dispatch => {
    dispatch({
        type: types.UPDATE_TICKETS,
        payload: ticketsData
      });
    
    callback(true);
  
};


export default types;
