import React, {useEffect, useState} from "react";
import PropTypes from "prop-types";
import Header from "../header";
import "../style.css"

const Ticket =(props)=> {
  const [selectedTicket, setSelectedTicket]=useState();
  const [ticketsDesc, setTicketsDesc]=useState("");
  const [ticketsStatus, setTicketsStatus]=useState();
  const [ticketsList, setTicketsList]=useState();

  let id=props.match && props.match.params && props.match.params.id;

  useEffect(()=>{
     let selectedItem=props.ticketsData && props.ticketsData.length>0 && props.ticketsData.find((item)=>item.id==id)
    setSelectedTicket(selectedItem);
    setTicketsDesc(selectedItem && selectedItem.desc)
  },[])

  useEffect(()=>{
    setTicketsList(props.ticketsData)
 },[props.ticketsData])

  const handleInput=(e)=>{
      setTicketsDesc(e.target.value)
    }

    const handleKeypress = e => {
      if (e.charCode === 13) {
      updateSelectedTicket();
      }
    };

    const updateSelectedTicket=()=>{
      ticketsList && ticketsList.length && ticketsList.forEach((item) => {
         if (item.id == selectedTicket.id) {
           item.desc=ticketsDesc;
           item.status=ticketsStatus?ticketsStatus:selectedTicket.status;
         }
      });
      if(ticketsDesc){
        props.updateTickets(ticketsList);
        props.history.push("/");
      }
    }

    const statusOnClick=(status)=>{
      setTicketsStatus(status);
    }

    return (
      <div className="wrapper ticket-detail">
       <Header h1="Sprint board" h2="Update ticket"/>
        {/* Ticket description */}
        <input type="text" value={ticketsDesc} onChange={(e)=>handleInput(e)} 
        onKeyPress={e=>handleKeypress(e)} className="desc-input"/>
        {!ticketsDesc && <div className="error">Please enter description</div>}

        {/* Ticket actions [Done/Not Fix/Close]. Modify to display them properly */}
       
        <div className="status-sec">
          <button onClick={()=>statusOnClick("DONE")} >Done</button>
          <button onClick={()=>statusOnClick("NOTFIX")} >Not Fix</button>
          <button onClick={()=>statusOnClick("CLOSE")} >Close</button>
        </div>

        <button className="action-btn" onClick={updateSelectedTicket}>
          UPDATE
        </button>
      </div>
    );
}

Ticket.propTypes = {
  ticketsData: PropTypes.array,
};



export default Ticket;
