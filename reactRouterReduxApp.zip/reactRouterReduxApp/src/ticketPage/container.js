import { connect } from "react-redux";
import * as commonActions from "../actions/commonAction";
import TicketPage from "./index";

const mapStateToProps = state => ({
  ticketsData: state.ticketsData,
});

const mapDispatchToProps = (dispatch) => ({
  updateTickets: (ticketsData, callback) => {
    dispatch(commonActions.updateTickets(ticketsData, callback));
  }
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TicketPage);
