import React, { useEffect, useState} from "react";
import Header from "../header";
import "../style.css"
import TicketCard from "../ticketCard";
const styles = {
    container: {
      display: "flex"
    },
    box: {
      flex: "0 1 33%",
      textAlign: "center",
      borderRight: "1px solid #ccc",
      label: {
        fontWeight: 600
      },
      ticket: {
        cursor:"pointer"
      }
    }
  };

const Home=(props)=>{
   const [ticketsList,setTicketsList]=useState([]);
   const [ticket,setTicket]=useState({id:"",desc:"",status:""});
   const [disableBtn,setDisableBtn]=useState(false);
   const [draggableItemStatus,setDraggableItemStatus]=useState();

   useEffect(()=>{
    setTicketsList(props.ticketsData);
   },[props.ticketsData])

   useEffect(()=>{
    setTimeout(() => {
      ticketsList && ticketsList.length && ticketsList.forEach((item) => {
        if (item.status === "DONE") {
          item.status="CLOSE";
          setTicketsList([...ticketsList]);
           props.updateTickets(ticketsList);
        }
        
    });
    
    }, 5000);
   },[ticketsList])

    const handleInput=(e)=>{
    setTicket({id:ticketsList.length,desc:e.target.value,status:"INPROGRESS"})
    }

    const addTicket=()=>{
    if(ticket && ticket.desc){
      const checkTicket=new Promise((resolve,reject)=>{
        if(ticket.desc){
          resolve("OK")
        }else{
          reject("ERROR")
        }
      });
      checkTicket.then(
        function(value){
          setDisableBtn(true);
          setTimeout(() => {
            props.addTickets(ticket);
            setTicketsList([...ticketsList,ticket])
            setTicket({id:"",desc:"",status:""})
            setDisableBtn(false);
          }, 2000);
        },
        function(error){
          console.log("error")
        }
      );
    }
    }


  const onDragStart = (event, item) => {
    	event.dataTransfer.setData("id", item.id);
      setDraggableItemStatus(item.status)
	}

	const onDragOver = (event) => {
	    event.preventDefault();
	}

	const onDrop = (event, stage) => {
	    let id = event.dataTransfer.getData("id");
	     ticketsList && ticketsList.length && ticketsList.forEach((item) => {
	        if (item.id == id) {
            item.status=stage;
	        }
	    });
      setTicketsList([...ticketsList]);
      props.updateTickets(ticketsList);
      setDraggableItemStatus("")
      if(stage==="DONE"){
        setTimeout(() => {
          ticketsList && ticketsList.length && ticketsList.forEach((item) => {
            if (item.id == id && item.status==="DONE") {
              item.status="CLOSE";
            }
        });
        setTicketsList([...ticketsList]);
        props.updateTickets(ticketsList);
        }, 5000);
      }
      
	}

    const handleKeypress = e => {
      if (e.charCode === 13) {
        addTicket();
      }
    };

    const ticketOnClick = id => {
      props.history.push(`ticket/${id}`)
    }

    return (
    <div className="wrapper">
        <Header h1="Sprint board" h2="Create ticket"/>
        <input 
          type="text"
          style={{ borderRadius: "3px" }}
          onChange={e=>handleInput(e)}
          value={ticket && ticket.desc}
          onKeyPress={e=>handleKeypress(e)}
          className="desc-input"
        />
        <button className={disableBtn?"action-btn disabled":"action-btn"} onClick={addTicket} disabled={disableBtn}>
          {disableBtn?"...":"ADD"}
        </button>
        
        <div style={styles.container}>
          <TicketCard classVal="draggable-sec" status="INPROGRESS" ticketsList={ticketsList}
          onDragStart={onDragStart} ticketOnClick={ticketOnClick}/>

          <TicketCard classVal="droppable-sec" isDroppable={true} status="DONE" ticketsList={ticketsList}
          onDragStart={onDragStart} ticketOnClick={ticketOnClick}  
          onDragOver={onDragOver} onDrop={onDrop}
          draggableItemStatus={draggableItemStatus}/>

          <TicketCard classVal="droppable-sec" isDroppable={true} status="NOTFIX" ticketsList={ticketsList}
          onDragStart={onDragStart} ticketOnClick={ticketOnClick}
          onDragOver={onDragOver} onDrop={onDrop} 
          draggableItemStatus={draggableItemStatus}/>

          <TicketCard classVal="droppable-sec" isDroppable={true} status="CLOSE" ticketsList={ticketsList}
          onDragStart={onDragStart} ticketOnClick={ticketOnClick}
          onDragOver={onDragOver} onDrop={onDrop}
          draggableItemStatus={draggableItemStatus}/>

        </div>
      </div>
    )
}
export default Home;