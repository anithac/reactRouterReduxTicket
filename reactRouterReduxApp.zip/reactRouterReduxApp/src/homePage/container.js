import { connect } from "react-redux";
import * as commonActions from "../actions/commonAction";
import HomePage from "./index";

const mapStateToProps = state => ({
  ticketsData: state.ticketsData
});

const mapDispatchToProps = (dispatch) => ({
  addTickets: (ticket,callback) => {
    dispatch(commonActions.addTickets(ticket, callback));
  },
  updateTickets: (ticketsData,callback) => {
    dispatch(commonActions.updateTickets(ticketsData, callback));
  }
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(HomePage);
