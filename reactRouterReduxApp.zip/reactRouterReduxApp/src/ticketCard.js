import React from "react";
import PropTypes from "prop-types";

const styles = {
  box: {
    flex: "0 1 33%",
    textAlign: "center",
    borderRight: "1px solid #ccc",
    label: {
      fontWeight: 600
    },
    ticket: {
      cursor:"pointer"
    }
  }
};

const TicketCard = ({
  classVal,
  status,
  ticketsList,
  onDragStart,
  ticketOnClick,
  isDroppable,
  onDragOver,
  onDrop,
  draggableItemStatus,
  ...props
}) => {
  let enableClsVal="";
  switch(draggableItemStatus){
    case "INPROGRESS":
      if(status==="DONE" || status === "CLOSE"){
        enableClsVal="droppable";
        }
        break;
    case "DONE":
      if(status==="CLOSE" || status==="NOTFIX"){
        enableClsVal="droppable";
      }
        break; 
    case "NOTFIX":
      if(status==="CLOSE" ){
        enableClsVal="droppable";
      }
        break; 
    case "CLOSE":
      break;
      default:break;                     
  }
  return (
    <div style={styles.box} className="heading-sec">
      <div className={classVal}>
        <label style={styles.box.label}>{status}</label>
        {/** show Todo tickets below */}
        {isDroppable && <div className={enableClsVal} onDragOver={(event)=>onDragOver(event)}
          		onDrop={(event)=>onDrop(event, status)}></div>}
        {ticketsList && ticketsList.length>0 && ticketsList.map((item,i)=>{
          if(item && item.status===status){
            return <div key={i} style={styles.box.ticket} 
          onDragStart = {(event) => onDragStart(event, item)}
          draggable className="ticket" onClick={()=>ticketOnClick(item.id)}>{item.desc}</div>
          }
        })}
      </div>
    </div> 
  );
};

TicketCard.propTypes = {
  classVal: PropTypes.string,
  status: PropTypes.string,
  ticketsList: PropTypes.array,
  onDragStart: PropTypes.func,
  ticketOnClick: PropTypes.func,
  isDroppable:PropTypes.bool,
  onDragOver:PropTypes.func,
  onDrop:PropTypes.func,
  draggableItemStatus:PropTypes.string
};

export default TicketCard;
