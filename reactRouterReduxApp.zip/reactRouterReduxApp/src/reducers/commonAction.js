import t from "../actions/commonAction";

const initialState = {
  ticketsData: []
};

export default (state = initialState, action) => {
  switch (action.type) {
    case t.ADD_TICKETS:
      return { ...state, ticketsData: [...state.ticketsData, action.payload] };
    case t.UPDATE_TICKETS:
      return { ...state, ticketsData:action.payload };
    case t.RESET:
      return initialState;
    default:
      return state;
  }
};


