import React from 'react';
import Home from "./homePage/container";
import Ticket from "./ticketPage/container";
import ReduxStore from "./reduxStore";
import { BrowserRouter, Switch, Route } from "react-router-dom";

function App() {
  return (
    <ReduxStore>
      <BrowserRouter>
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/ticket/:id" component={Ticket} />
        </Switch>
      </BrowserRouter>
    </ReduxStore>
  );
}

export default App;
