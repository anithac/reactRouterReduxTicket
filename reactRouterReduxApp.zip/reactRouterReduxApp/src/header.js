import React from "react";
import PropTypes from "prop-types";

const Header = ({
  h1,
  h2,
  ...props
}) => {
  
  return (
    <>
    <h1>{h1}</h1>
    <h2>{h2}</h2>
    </>
  );
};

Header.propTypes = {
  h1: PropTypes.string
};

export default Header;
