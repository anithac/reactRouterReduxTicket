import React from "react";
import { Provider } from "react-redux";
import logger from "redux-logger";
import { createStore, applyMiddleware } from "redux";
import thunk from "redux-thunk";
import reducers from "./reducers/commonAction";
import { composeWithDevTools } from "redux-devtools-extension";


export default ({ children, initialState = {} }) => {
  const store = createStore(
    reducers,
    composeWithDevTools(applyMiddleware(thunk, logger))
  );


  return <Provider store={store}>{children}</Provider>;
};
